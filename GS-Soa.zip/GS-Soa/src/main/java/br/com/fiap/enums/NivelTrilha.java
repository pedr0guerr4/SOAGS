package br.com.fiap.enums;

public enum NivelTrilha {
    INICIANTE,
    INTERMEDIARIO,
    AVANCADO
}
